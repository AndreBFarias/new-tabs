#### [Chrome](https://www.google.com/chrome)

##### Instalação via Git

Se você usa Git, pode instalar e manter o tema atualizado clonando o repositório:

```bash
git clone https://github.com/AndreBFarias/codex-dracula-new-tab.git
```

### Instalação manual
Faça o download usando a opção Download .zip do GitHub e extraia os arquivos.

### Ativando a extensão
Acesse [Chrome](chrome://extensions/) ou chrome://extensions/ no seu navegador;

### Ative o Modo do desenvolvedor (canto superior direito);

Clique em “Carregar sem compactação”;

Selecione a pasta codex-dracula-new-tab/chrome/.
